#include "customer.h"

Customer::Customer(std::string name, int ticket)
{
    _name = name;
    _ticket = ticket;
}

std::string Customer::name()
{
    return _name;
}

int Customer::ticket()
{
    return _ticket;
}