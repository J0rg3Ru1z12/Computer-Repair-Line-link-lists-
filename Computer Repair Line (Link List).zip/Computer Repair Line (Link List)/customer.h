#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

class Customer
{
public:
    // Creates a customer with a name and repair ticket number.
    Customer(std::string name, int ticket);

    // Returns the customer's name.
    std::string name();

    // Returns the customer's repair ticket number.
    int ticket();

private:
    std::string _name;
    int _ticket;
};

#endif