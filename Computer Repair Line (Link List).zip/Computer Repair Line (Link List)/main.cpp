#include <iostream>
#include "repairqueue.h"

using namespace std;

int failures = 0;

void check(bool condition, const char* description)
{
    if (condition)
    {
        cout << "PASS: " << description << '\n';
    }
    else
    {
        cout << "FAIL: " << description << '\n';
        ++failures;
    }
}

int main()
{
    Customer ana("Ana", 101);
    Customer ben("Ben", 102);
    Customer carlos("Carlos", 103);
    Customer diana("Diana", 104);

    RepairQueue line;

    // Part A: A new waiting line is empty.
    check(line.size() == 0, "New line has size 0");
    check(line.next_customer() == nullptr,
        "New line has no next customer");

    // Part B: Serving an empty line changes nothing.
    line.serve();
    line.serve();

    check(line.size() == 0,
        "Serving an empty line keeps size 0");
    check(line.next_customer() == nullptr,
        "Serving an empty line leaves no front customer");

    // Part C: The first customer joins.
    line.join(&ana);

    check(line.size() == 1, "One customer is waiting");
    check(line.next_customer() == &ana,
        "Ana is first");

    // Looking at the next customer must not remove them.
    check(line.next_customer() == &ana,
        "Repeated inspection still returns Ana");
    check(line.size() == 1,
        "Inspecting the front does not change size");

    // Part D: More customers join.
    line.join(&ben);
    line.join(&carlos);

    check(line.size() == 3,
        "Three customers are waiting");
    check(line.next_customer() == &ana,
        "Ana remains first after others join");

    // Part E: Serve one customer, then add another.
    line.serve();

    check(line.size() == 2,
        "Serving Ana leaves two customers");
    check(line.next_customer() == &ben,
        "Ben is now first");

    line.join(&diana);

    check(line.size() == 3,
        "Diana joins the remaining line");
    check(line.next_customer() == &ben,
        "Diana joining does not change the front");

    // The remaining order must be Ben, Carlos, Diana.
    line.serve();

    check(line.size() == 2,
        "Serving Ben leaves two customers");
    check(line.next_customer() == &carlos,
        "Carlos is now first");

    line.serve();

    check(line.size() == 1,
        "Serving Carlos leaves one customer");
    check(line.next_customer() == &diana,
        "Diana is now first");

    // Part F: Remove the final customer.
    line.serve();

    check(line.size() == 0,
        "Serving Diana empties the line");
    check(line.next_customer() == nullptr,
        "An emptied line has no next customer");

    // Part G: Reuse the queue with one customer at a time.
    for (int i = 0; i < 3; ++i)
    {
        line.join(&ana);

        check(line.size() == 1,
            "Reused line contains one customer");
        check(line.next_customer() == &ana,
            "Reused line returns Ana");

        line.serve();

        check(line.size() == 0,
            "Reused line becomes empty again");
        check(line.next_customer() == nullptr,
            "Reused line has no front after serving");
    }

    // Part H: Two queues must operate independently.
    RepairQueue other_line;

    line.join(&ben);
    other_line.join(&carlos);

    check(line.next_customer() == &ben,
        "First line contains Ben");
    check(other_line.next_customer() == &carlos,
        "Second line contains Carlos");

    line.serve();

    check(line.size() == 0,
        "First line is now empty");
    check(other_line.size() == 1,
        "Serving first line does not change second line");
    check(other_line.next_customer() == &carlos,
        "Carlos remains in second line");

    other_line.serve();

    // Part I: Customer objects must still exist.
    check(ana.name() == "Ana",
        "Ana's object still exists");
    check(ben.ticket() == 102,
        "Ben's ticket is unchanged");
    check(carlos.ticket() == 103,
        "Carlos's ticket is unchanged");
    check(diana.name() == "Diana",
        "Diana's object still exists");

    cout << '\n';

    if (failures == 0)
    {
        cout << "Repair queue practice complete: all tests passed.\n";
    }
    else
    {
        cout << failures << " test(s) failed.\n";
    }

    return failures == 0 ? 0 : 1;
}