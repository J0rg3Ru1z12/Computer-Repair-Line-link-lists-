//***********************************************************************
// Name:
// Linked-List Practice — Level 1, Exercise 2
// File: repairqueue.cpp
//
// Implements a computer repair shop's waiting line.
//***********************************************************************

#include "repairqueue.h"

// Part 1: Initialize an empty waiting line.
// Constructs an empty waiting line.
RepairQueue::RepairQueue()
{
    // TODO
    head = nullptr;             //  assigns the front of the line to be empty
    tail = nullptr;             //  assigns the back of the line to be empty
    count = 0;                  //  shows that they're are no people in line
}

// Part 2: Report the number of waiting customers.
int RepairQueue::size()
{
    // TODO: Replace the placeholder return.
    return count;           //  returns the amount of people waiting
}

// Part 3: Add a customer at the back.
// Adds a customer to the back of the waiting line.
// Assume customer is not nullptr.
void RepairQueue::join(Customer* customer)
{
    // TODO
    Node* new_node = new Node;              //  creates a new node 
    new_node->customer = customer;          //  then uses said node to point to customer and create another copy of them 
    new_node->next = nullptr;

    if (head == nullptr)
    {
        head = new_node;
    }
    else
    {
        tail->next = new_node;
    }

    tail = new_node;
    count++;
}

// Part 4: Inspect the customer at the front.
// Returns the address of the customer at the front.
// Does not remove the customer.
// Returns nullptr if the waiting line is empty.
Customer* RepairQueue::next_customer()
{
    if (head == nullptr)
    {
        return nullptr;
    }
    // TODO: Replace the placeholder return.
    return head->customer;
}

// Part 5: Remove the customer at the front.
// Removes the customer at the front of the waiting line.
// Does nothing if the line is empty.
// Deletes the queue node, NOT the Customer object.
void RepairQueue::serve()
{
    // TODO
    if (head == nullptr)
    {
        return;
    }

    Node* old_head = head;

    head = old_head->next;

    if(head == nullptr)
    {
        tail = nullptr;
    }

    delete old_head;

    count--;

}