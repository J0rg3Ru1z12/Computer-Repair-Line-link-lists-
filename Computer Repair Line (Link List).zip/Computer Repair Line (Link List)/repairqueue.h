#ifndef REPAIRQUEUE_H
#define REPAIRQUEUE_H

#include "customer.h"

class RepairQueue
{
public:
    // Constructs an empty waiting line.
    RepairQueue();

    // Returns the number of customers waiting.
    int size();

    // Adds a customer to the back of the waiting line.
    // Assume customer is not nullptr.
    void join(Customer* customer);

    // Returns the address of the customer at the front.
    // Does not remove the customer.
    // Returns nullptr if the waiting line is empty.
    Customer* next_customer();

    // Removes the customer at the front of the waiting line.
    // Does nothing if the line is empty.
    // Deletes the queue node, NOT the Customer object.
    void serve();

private:
    class Node
    {
    public:
        Customer* customer;
        Node* next;
    };

    Node* head;
    Node* tail;
    int count;
};

#endif